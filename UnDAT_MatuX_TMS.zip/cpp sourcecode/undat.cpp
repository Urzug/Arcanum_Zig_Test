/*
					Arcanum's Undat

			Developed by MatuX @ The Mod Squad
		 Using Microsoft Visual C++ 6.0 Enterprise

    About the zlib sources.. I have *slightly* modified their
  sources so it would show that nifty '.' while decompressing
  files. Since they're modified sources, I won't distribute
  them.

    This sourcecode has been released for educational 
  purposes only. If you find a way to make things faster,
  please contact me at matiasp@noland-studios.com.ar!

  Compression library used:
	Zlib version 1.1.3, July 9th, 1998
	Copyright (C) 1995-1998 Jean-loup Gailly and Mark Adler.

  Source notes:
    I used a combination of both C and C++. In the beggining
  it was going to be a pure C++ program but I figured I was
  expending too much time creating though classes where I
  would just use 20% of what was in them (I prefer to let
  them for a more complex program like an Arcanum's 
  DATMan-class program).
    I'm using io.h functions for binary file handling cause
  I found I cannot understand that stupid iofstream ;).

*/

#include <iostream>
#include <ios>
#include <iomanip>
#include <fstream>
#include <string>
#include <new.h>
#include <ctime>
#include <stdlib.h>
#include <direct.h>
#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <errno.h>
#include <string.h>
#include <windows.h>
#include "zlib\zlib.h"
#include "undat.h"

using namespace std;

//////////////////////////////////////////////////////////////////////////
//
//     Constant screen output stuff
//
inline void PrintWelcome()
{
	cout << endl << "Arcanum's Undat v1.0 - Unpacks an Arcanum's DAT file"
	     << endl << "Coded by MatuX @ The Mod Squad, 2001 - matiasp@noland-studios.com.ar"
		 << endl;
}
inline void PrintUsage() { cout << endl << "Usage: undat datfile [destdir] [-l]" << endl; }
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//
//      Inline pathfile string manipulator functions
//
inline void removefname(char *string) { string[strrchr(string, '\\') - string] = '\0'; }
inline void removepath(char *string)  { strcpy(string, (strrchr(string, '\\') + 1)); }
inline void removeext(char *string)   { string[strrchr(string, '.') - string] = '\0'; }
inline void changeext(char *ext, char *string) { string[strrchr(string, '.') - string + 1] = '\0'; strcat(string, ext); }
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//
//      Functions for dirs
//
bool direxists(char *dir)
{
	// Uses Win32 API! //
	
	HANDLE		    fFile;
	WIN32_FIND_DATA	fileinfo;

	fFile = FindFirstFile(dir, &fileinfo);

	if(fileinfo.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
	{
		FindClose(fFile);
		return(true);
	}

	FindClose(fFile);
	return(false);
}

int getdirnodeamount(const char *dir)
{
	int nodeamount = 0;

	for( int x = 0; x <= strlen(dir); x++ )
		if( dir[x] == '\\' )
			++nodeamount;

	return(nodeamount);
}

void getdirnode(const char *dir, int node, char *buffer)
{
	int nodenumber = 0;
	int charamount = 0;

	for( int x = 0; x <= strlen(dir); x++ )
	{
		if( dir[x] == '\\' )
			++nodenumber;
		if( nodenumber == node )
		{
			for( int y = x + 1; dir[y] != '\\' && dir[y] != '\0' ; y++ )
				++charamount;
			strcpy(buffer, dir);
			buffer[(x + 1) + charamount] = '\0';

			return;
		}
	}
}
//
//////////////////////////////////////////////////////////////////////////

int err_OutOfMemory(size_t size)
{
	cout << endl << "There is not enough memory to allocate " << size 
		 << endl << "Program terminated abnormally due to lack of memory";
	exit(-1);
	return(-1);
}

//////////////////////////////////////////////////////////////////////////
//
//     int main(int argc, char *argv[], char *envp[])
//
int main(int argc, char *argv[], char *envp[])
{
	/*
	     Arguments
		[0] = app path
		[1] = datfile
		[2] = destination
		[3] = dolist
	*/
	try
	{
		unsigned int namesize;
		int       fdat, ilist = nolist;
		bool	  curpath = true;
		char     *destpath,
				 *name = new char[MAXPATH];
		STreeItem treeitem;
		
		_set_new_handler(err_OutOfMemory);
		
		PrintWelcome();

		// check arguments
		if( argc >= 5 )
		{
			cout << "Wrong arguments";
			PrintUsage();
			throw;
		}
		else if( argc == 1 )
		{
			PrintUsage(); 
			return(0);
		}
		
		if( argc >= 3 )
			if( strchr(argv[2], '\\') != NULL )
				curpath = false;
			else if( !stricmp(argv[2], "-l") ) 
				ilist = wide;
			else if( !stricmp(argv[2], "-lf") )
				ilist = full;
			else 
				if( argc >= 4 ) 
					if( !stricmp(argv[3], "-l") ) 
					{ 
						ilist = wide;
						curpath = false;
					}
					else if( !stricmp(argv[3], "-lf") )
					{
						ilist = full;
						curpath = false;
					}

		if( !curpath )
		{
			destpath = strcpy(new char[MAXPATH], argv[2]);
			if( !((strrchr(argv[2], '\\') - argv[2] + 1) 
					== 
				  (strlen(argv[2]))) )
				strcat(destpath, "\\");
		}
		else
		{
			destpath = new char[MAXPATH];
			strcpy(destpath, argv[0]);
			// rip the filename from a filepath
			removefname(destpath);
			strcat(destpath, "\\");
		}

		// create destpath, if -1, evaluate the error
		if( mkdir(destpath) == -1 )
			if( errno == ENOENT ) 
				throw "Could not create destination path directory";

		// open the dat
		if( (fdat = (open(argv[1], _O_BINARY|_O_RDONLY))) == -1 ) 
			throw "Could not open DAT file";

		// get DAT2.1 main data
		char *unk1[UNK1_LEN], *unk2[UNK2_LEN];
		int unk3, treesubs, filestotal;
		
		lseek(fdat, -0x1Cl, SEEK_END);
		read(fdat, unk1, UNK1_LEN);
		read(fdat, unk2, UNK2_LEN);
		read(fdat, &unk3, 0x04);
		read(fdat, &treesubs, 0x04);
		lseek(fdat, -treesubs, SEEK_END);
		read(fdat, &filestotal, 0x04);
		
		// extract or list files on DAT
		if( ilist == nolist )
		{
			unsigned char *psbuffer, *rsbuffer;
			unsigned long ulrsize = 0;
			char *datdir  = strcpy(new char[MAXPATH], destpath);
			char *itemdir = new char[MAXPATH];
			char *itemfname = new char [MAXPATH];
			char *dirnode = new char[MAXPATH];
			long treepos = 0;
			int dnamount = 0, x = 0, y = 0, fdfile = 0, z_err = 0;

			cout << endl << "Extracting..." << endl;

			char *datname = strcpy(new char[MAXPATH], argv[1]);
			if( strchr(argv[1], '\\') != NULL )
				removepath(datname);
			removeext(datname);
			strcat(datdir, datname);
			delete [] datname;

			if( !direxists(datdir) )
				mkdir(datdir);

			for( x = 1; x <= filestotal; x++ )
			{
				read(fdat, &namesize, 0x04);
				read(fdat, name, namesize);
				read(fdat, &treeitem, sizeof(treeitem));
				treepos = lseek( fdat, 0x00l, SEEK_CUR );

				cout << endl << name << "  " << x << "/" << filestotal;

				//work out the dirs
				/*
				    this routine is a complete mess
					so, dont try to understand it ;)

					basically, it (tries) to recreate the
					tree directory information stored in
					the .DAT only when a certain dir doesnt
					exists.
				*/

				strcpy(itemdir, datdir);
				strcat(itemdir, "\\");
				strcat(itemdir, name);
				strcpy(itemfname, itemdir);
				if( treeitem.Type != DIRECTORY ) 
					removefname(itemdir);

				if( !direxists(itemdir) )
				{
					dnamount = getdirnodeamount(name);
					
					if( (dnamount == 0 || dnamount == 1) && treeitem.Type != DIRECTORY ) 
						mkdir(itemdir);
					else
					{
						if( treeitem.Type != DIRECTORY )
							--dnamount;
						for( y = 0; y <= dnamount; y++ )
						{
							getdirnode(name, y, dirnode);
							strcpy(itemdir, datdir);
							strcat(itemdir, "\\");
							strcat(itemdir, dirnode);
							mkdir(itemdir);
						}
					}
				}

				switch( treeitem.Type )
				{
				case COMPRESSED:
					psbuffer = new unsigned char[treeitem.PackedSize];
					rsbuffer = new unsigned char[treeitem.RealSize];

					// goto offset on DAT
					lseek(fdat, treeitem.Offset, SEEK_SET);
					// read the file
					read(fdat, psbuffer, treeitem.PackedSize);
					// open a file to flush the buffer
					if( (fdfile = open(itemfname, _O_BINARY|_O_CREAT|_O_WRONLY|_O_TRUNC, _S_IREAD|_S_IWRITE)) == -1 )
					{
						delete [] itemdir;
						delete [] datdir;
						delete [] dirnode;
						delete [] psbuffer;
						delete [] rsbuffer;
						close(fdat);						
						throw "Could not open file for extraction";
					}
					ulrsize = static_cast<unsigned long>(treeitem.RealSize);
					z_err = uncompress(rsbuffer, &ulrsize, psbuffer, treeitem.PackedSize);
					switch( z_err )
					{
					case Z_OK:
						write(fdfile, rsbuffer, treeitem.RealSize);
						break;
					case Z_MEM_ERROR:
						cout << endl << "	There is not enough memory to decompress this file" << endl;
						break;
					case Z_BUF_ERROR:
						cout << endl << "	There is not enough space on the output buffer to decompress this file" << endl;
						break;
					case Z_DATA_ERROR:
						cout << endl << "	The data on the input file is corrupted thus cannot be decompressed" << endl;
						break;
					default:
						cout << endl << "	Error while decompressing!" << endl;
						break;
					}

					delete [] psbuffer;
					delete [] rsbuffer;
					close(fdfile);
					break;
				case UNCOMPRESSED:
					rsbuffer = new unsigned char[treeitem.RealSize];

					// goto offset on DAT
					lseek(fdat, treeitem.Offset, SEEK_SET);
					// read the file
					read(fdat, rsbuffer, treeitem.RealSize);
					// open a file to flush the buffer
					if( (fdfile = open(itemfname, _O_BINARY|_O_CREAT|_O_WRONLY|_O_TRUNC, _S_IREAD)) == -1 )
					{
						delete [] itemdir;
						delete [] datdir;
						delete [] dirnode;
						delete [] psbuffer;
						delete [] rsbuffer;
						close(fdat);						
						throw "Could not open file for extraction";
					}
					write(fdfile, rsbuffer, treeitem.RealSize);

					delete [] rsbuffer;
					close(fdfile);
					break;
				case DIRECTORY: // we skip dirs
					cout << " DIRECTORY type item -> dir created successfully";
					break;
				}

				// get back where we left
				lseek( fdat, treepos, SEEK_SET );
			}

			delete [] itemdir;
			delete [] datdir;
			delete [] dirnode;

			cout << endl << endl << filestotal << " files were succesfully extracted and decompressed!" << endl;
		}
		else
		{
			// get filename
			char *lstname = strcpy(new char[MAXPATH], argv[1]);
			if( strchr(lstname, '\\') != NULL )
				removepath(lstname);
			changeext("lst", lstname);

			ofstream datlst(strcat(destpath, lstname), ios::out);
			if( !datlst.is_open() )
			{
				delete [] lstname;
				throw "Could not create/truncate .LST file for listing";
			}

			time_t osBinaryTime = time(&osBinaryTime);
			datlst.setf(ios::showbase);
			datlst << "Arcanum's Undat v1.0 by MatuX @ The Mod Squad" << endl
				   << "---------------------------------------------" << endl
				   << endl << "Listing of " << argv[1] << " created on " << ctime(&osBinaryTime)
				   << endl;

			for( int x = 1; x <= filestotal; x++ )
			{
				read(fdat, &namesize, 0x04);
				read(fdat, name, namesize);
				read(fdat, &treeitem, sizeof(treeitem));

				if( ilist == full )
					datlst << "------------------"
						   << endl << "  NameSize: " << dec << namesize << " / " << hex << namesize
						   << endl << "      Name: " << name
						   << endl << "  Unknown1: " << dec << treeitem.Unknown1   << " / " << hex << treeitem.Unknown1  //((treeitem.Type == COMPRESSED) ? ("Compressed"): ((treeitem.Type == UNCOMPRESSED) ? ("Uncompressed") : ("Unknown")))
						   << endl << "      Type: " << dec << treeitem.Type       << " / " << hex << treeitem.Type
						   << endl << "  RealSize: " << dec << treeitem.RealSize   << " / " << hex << treeitem.RealSize
						   << endl << "PackedSize: " << dec << treeitem.PackedSize << " / " << hex << treeitem.PackedSize
						   << endl << "    Offset: " << dec << treeitem.Offset     << " / " << hex << treeitem.Offset
						   << endl;
				else
					datlst << name << endl;
				
				if( datlst.fail() )
				{ 
					datlst.close();
					close(fdat);
					delete [] lstname;
					throw "Error while listing files";
				}
			}

			cout << endl << "With " << filestotal << " files listed, " << destpath << " was created succesfully" << endl;

			delete [] lstname;
			datlst.close();
		}
		
		close(fdat);

		return(0);
	}
	catch(char *e)
	{
		cerr << endl << e << endl;
		return(1);
	}
	catch(...)
	{
		cerr << endl << "Unhandled exception error!" << endl;
		return(-1);
	}
}
