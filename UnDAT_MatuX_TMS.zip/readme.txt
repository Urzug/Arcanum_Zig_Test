Important Note:
---------------

Be careful, this version was only tested with Arcanum's demo and was released BEFORE Arcanum's retail. If this program needs to be remade for the final Arcanum, I will do it.

	- MatuX @ The Mod Squad