qtScribe by AA Team
Version 0.8, 14 of November, 2009.

qtScribe is an all-in-one tool for editing most files used by "Arcanum: of Steamworks and Magick Obscura".
Included is support for .scr (Arcanum scripts), .pro, .mes and basic support for .dlg.


Installation
============
This package contains binary files for Linux x86_64 and win32. Unpack and execute.
Based on Qt4 library. You may get it at http://www.qtsoftware.com/products/developer-tools

You may select Arcanum working dir from the Configure dialog.
.scr, .mes, .pro and .art file must be unpacked from *.dat


General questions
=================
qtScribe will look for the files in a data subdirectory of the chosen Arcanum base dir. If no files are
listed in .mes,.scr,or .pro view, check if you have the files unpacked to
<chosen directory>/data/ and if not move them there.

Font preferences could be tweaked in qtScribe.ini. Make sure to specify full name of the font family.


.scr editor
===========
Double-click a script line to change its operation code.


.mes editor
===========
Should be fairly self-explanatory.
It is recommended that you use the "Save as" feature instead of overwriting the original file.
WARNING: If you save using a wrong codepage (if strange characters are shown)
         you may not be able to recover the original state of the file.


.dlg editor
===========
At the moment this is still included in the same tab as the .mes editor and offers no advanced
features since it is the first release (and the version number is still below 1.0)


.art editor
===========
Double-click a palette line to edit it.

Due to engine limitations it's not possible to have more than four palettes in an .art file.

Add/remove palette function is experimental. You can try anyway but it could happen that
Arcanum crashed or does other funny things.

Check palettes compatibility when pasting images from the clipboard.

Art frames are organized in the form of a rectangular matrix. When you remove an image,
you remove all of it's frames. When you remove a frame, you remove every frame of same index
in all of the images contained in this .art.

.art files containing fonts consist of a single frame and 255 images, of which the first is never compressed.


.pro editor
===========
Highly experimental. Arcanum's .pro file format is the hard target to crack.


Technical
=========
Info used:
- ArtView (eml78)
- ScriptEd v1.50 beta 3 (DjUnique)
- arcanumedit (David Green)
- ProtoEdit (eml78)
- WorldEd manual (Troika)
- ART format description (Crypton)
- PRO format description (Crypton)

win32 is not tested as well as Linux. It's third millenium, use Linux.

DejaVu Sans font is used in the GUI. Install it if your system lacks it.

You may reach us on radzh(at)game-alive.com
Or look for radzh at http://www.arcanumclub.ru/ forum.


Developers
==========
AA-Team stands for ArcanumAlive Team. We develop editor tools, multiplayer mods
and so on for the "Arcanum: of Steamworks and Magick Obscura" videogame.
qtScribe editor made by radzh and Koorac.


Version history
===============
0.8
+ .dlg editor vastly improved.
+ Save/load and copy/paste for .art palettes.
+ Center-codes (deltaX/deltaY) setting for animated .arts.
+ SaveAs for .pro, overwriting .pro.
! .pro saving fixed.
! Fixes.

0.7.2
+ Added window icon.
! Fixed potential crash when editing malformed .dlg files.

0.7.1
! Fixed bug in .mes code that caused line not to be shown completely.

0.7
* Koorac is now part of the team.
+ Configure dialog.
+ Working dir selection GUI.
+ .mes editor improvement.
+ Codepage selection for .mes and .dlg.
+ Experimental .dlg editing.
+ .pro editor improvement.
- .pro editor cleanup.
! Artfile optimization.
! Fixes.

0.6
+ Animation flag support for .arts.
+ Font tweaking in qtScribe.ini file.
+ Experimental .pro editing.
+ Experimental .pro saving to data/pro/00000.pro
+ Read-only mode for .scr by default.
+ Support for Cyrillic symbols in .mes, 1251 codepage.
! Fixes.

0.5
+ .art viewing.
+ Palette editing.
+ Experimental .art saving to data/qtScribe.test.ART. Rename and use.
+ Export to BMP, JPG, PNG, TIFF - data/qtScribe.export.XXX files.
+ Copy/paste to/from system clipboard buffer.
+ Palette adding/removing.
+ Images/frames adding/removing.
! Fixes.

0.4
+ Basic .mes editing.
+ win32 build.
! Fixes, refactoring.

0.3
+ Value type parsing - Counter, Global Var etc.
+ Script description editor.
+ About dialog.
! Fixes.

0.2
+ IF and DO expression added.
+ .scr format saving.
+ Single expression deleting.
+ Moving expression line up or down.
+ Expression opcode changing.

0.1
Initial build, .pro viewer only. Only small part of opcodes is deciphered. By radzh.

===
