#Arcanum Factory 1.4.1 - ReadMe.txt - [01/2020]


#Informations


 -Name         : Arcanum Factory
 -Description  : Modding Tool
 -Version      : 1.4.1 (01-2020)
 -License      : Freeware
 -Author       : FilthyJack (filthyjack@lotusrevenge.fr)

This Modding Tool is meant to be used with patch 1074 + UAP 1.4, this is what I consider a clean (bug fixed) but unaltered experience.

Arcanum Factory allows you to easily add new content to the game or WorldEd. 
You can also modify game files directly but don't forget to import them ( Factory->Import ) so they are not wiped by the 'Restore Arcanum' action.


#Features

-All Language Supported
-Create new Weapons
-Create new Armors (everything else you can equip)
-Create new Items (Generic/Scroll/Consumable)
-Create new Schematics
-Create new ART to use with your items
-Create new Backgrounds
-Create new Effects and auto-assign them to your items
-Add new item names/descriptions
-Modify Shops/Containers/Inventories
-Test your stuff directly in Arcanum or WorldEd
-Create an auto-install Package to share your project
-You can also alter the game files directly if you want
-Extract Arcanum maps and edit them in WorldEd
-Capture only the needed worlded files for your campaign mod
-GUI interface with a lot of tips
-Restore Arcanum Content anytime with just one click
-Fix slowdowns on recent Windows (wined3d method)
-Compatible with Windows, Wine/PlayOnLinux or VBox
-Also compatible with GOG version of the game (pre-patched to 1074)


#Compatibility


Arcanum Factory 1.4.1 is compatible with Windows (XP/7/Recent) and Linux (VBox/Wine).
Also compatible with the GOG version of the game.
Arcanum Factory uses Arcanum\data Arcanum\modules\Arcanum.PATCH5-6 so make sure you have a backup of other content you have there.


#Install


I recommend extracting Arcanum Factory inside Arcanum folder.
Never Install it in Program Files folder!

My recommended setup (on a separate partition):

-Arcanum (GOG)
-Patch 1074                 (required)
-UAP With Extra Content 1.4 (required)
-UAP Extra Animations
-HQ TownMaps
-HQ Music wav
-High Resolution

All of these are available at terra-arcanum.com, the download section may not contain the latest versions like for the high res mod, just visit the forums sticky in the modding section to find them.


#Usage


When you're done creating items, you can use the 'Apply to Arcanum' option to test your work directly in Arcanum and WorldEd.
You may need to use the 'Restore Arcanum Content' option to clean previous mods before applying again.
You can produce an auto-install mod with a readme file and a png preview, ready to be zipped and shared, located inside ArcanumFactory\Conf\Pack\Compiled\my_mod_name after creation. 

If you're lost or need more information, please come to the forums and ask your questions.


#Descriptions


When you add descriptions/names/internal names you need to modify both Game and Factory versions if you want them to appear in the interface. They are easily accessed with the mes editor. Sometimes you need to restart Arcanum Factory to make them appear in the interface.


#WorldEd Menu


When editing Arcanum in worlded, NEW files and modified sectors can be retrieved (after saving the map) by clicking "Retrieve mod/sec files". Then if you further modify them you will need to hit "Retrieve latest version" to make sure you save the changes.

When modifying exising Arcanum (npcs, items, containers), you HAVE to use "Capture mob files from clipboard", then right click the modified objects individually in worlded and hit the "G_XXXXXXX" text at the bottom, a confirmation popup will appear, then if you modify these files again all you have to do is hit "Retrieve latest versions".

If you follow those instructions carefully you will end up with Arcanum/modules/Arcanum.PATCH_CLEAN containing a clean and stripped down version of you modifications to the Campaign Module. When everthing is done, hit "Delete extracted campaign", and rename your Arcanum.PATCH_CLEAN to Arcanum.PATCH5 and test your mod. 

You can then add your final PATCH5 file to the modules folder of your Arcanum Factory's Mod Installer or share it like that telling your friends to extract it in Arcanum\modules\.


#Mod Installer

This tool creates a folder with the name of your mod. Inside is the readme.txt containing a description and a preview png (if none selected then the default one will be used instead).

Files you need to share the mod:

ArcanumFactory\Factory\Pack\Compiled\my_mod_name\
ArcanumFactory\Factory\Pack\Compiled\Arcanum_Mod_Manager.exe

If you really know what you are doing then you may want to distribute it as several optional components, aside from file conflicts, all you need to do is to create different folders next to your mod_name folder and include the component's files in there with same directory structure as your mod or Arcanum itself. 

It is fine as long as you know the optional components override each other in the original order.
In that case the main component holds all the descriptions and the other overrides the previous containers with content of (1)+(2).

[ ] Items Pack 1 (all descriptions + containers 1)
[ ] Items Pack 2 (overrides with containers 1 + 2)


In this case all components are independant.

[ ] Item Pack
[ ] Portrait Pack
[ ] Dialogue Mod


#Utilities


 -I am not the author of these tools.
 -The savegame editor may require that you copy the provided dll/ocx to your Windows/System32 folder and register them.
 -Although they are properly credited, I have never been in contact with their authors.



#Factory Info


Override:

 -Arcanum\modules\Arcanum.PATCH5-6
 -Arcanum\data\mes\
 -Arcanum\data\rules\
 -Arcanum\data\art\interface\
 -Arcanum\data\art\item\
 -Arcanum\data\scr\30500Apply_4_Effects.scr 30501Remove_4_Effects.scr
 -Arcanum\data\proto\


Ranges:

 -Arcanum Factory will automatically patch/restore Arcanum.exe and WorldEd.exe to increase ranges.

 -New Descriptions/Internals (40000-41200)
 -New Protos ( )
 -New Backgrounds (790- 1790)
 -New BG Text (1077-1177)
 -New Effects (359-3000)
 -New Scematic Text ( )


Config Files:

ArcanumFactory\Factory\Conf\*.mes
Do not modify these files unless you know exactly what you are doing.
LanguageUS.lang is a text file containing the tooltips, if you need to translate or modify them but don't add or remove lines.



#Credits


 - Filthy Jack       ( Author: Design & Code & Hacks )


 - DKoepp            ( Docs )
 - Otto Krupp        ( Docs )
 - Tekkus McDwarf    ( Docs )
 - Drog Black Tooth  ( Docs & UAP )
 - Leonidus          ( Docs & Support )

 - T.Pitkanen        ( DatBuilder & ScriptEditor )
 - Zammy             ( Dialog Editor )
 - DKoepp            ( SaveGame Editor )

 - Shiin & RRoyo     (Campaign Unpacking Method)



 
If you want to report a bug, comment or suggest something then please send me a mail or post in the release thread.
Thanks to terra-arcanum and rpgcodex for being awesome!
Special thanks to RunawayScientist, DrogBlackTooth, Crypton, DarkElf, DarkUnderlord, Taluntain, Corvell, DJ_Unique and everyone who supported the project!
 
Happy Modding!


 -Filthy Jack
