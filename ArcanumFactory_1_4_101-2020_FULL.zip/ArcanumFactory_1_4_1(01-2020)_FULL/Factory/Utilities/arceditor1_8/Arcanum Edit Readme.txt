
ARCANUM EDITOR

***    TABLE OF CONTENTS          ***
*I*    ABOUT ARCANUM EDITOR       *I*
*II*   REVISION HISTORY           *II*
*III*  POSSIBLE ADDITIONS         *III*
*IV*   KNOWN PROBLEMS             *IV*
*V*    INSTALLATION AND USAGE     *V*
*VI*   RACE AND GENDER EDITING    *VI*
*VII*  FREQUENTLY ASKED QUESTIONS *VII*
*VIII* SPECIAL THANKS             *VIII*



*I* ABOUT ARCANUM EDITOR *I*
 
Arcanum Edit is a project that I just started in my free time. Since 
the full game was not released then,I started using the demo, but as  
the game is now out. I have tested this editor on it and it does work.




*II* REVISION HISTORY *II*

Version 1.8
* Health has been started though at the moment it currently uneditable
  as in almost all npcs it is wrong and in most low level pcs it is 
  wrong.
* Tollo Underhill, Weldo Rubin, and Loghaire Thunderstone are now in 
  the editor. Now All permenant Npcs are in the editor.
* Arronax and Gorgoth are now in the editor.
* Learned Schematics now can be changed into any other learned 
  schematic.
* Race and Gender are now changable(See section on this for more 
  details).
* Magick/Tech bar has been improved to allow more choices.
* The Bane of Kree and Kraka-Tur are now in the editor.
* Sebastion and Franklin Payne are now in the editor.

Version 1.7
* Found a bug that caused some characters to be the wrong due to
  their age. Fixed that one.
* Some characters like the dog and Waromon have skills that do not show
  up in the editor. Rather then worry about how to change them without
  corrupting the game, I just disabled the use of that portion of the 
  editor for that character.
* Torian Kel, Waromon, and Thorvald Two Stones are now in the editor.
* Geoffrey Tarellond-Ashe, Dante, and the Dog are now in the editor.
* Found out that Raven and Perriman did not show up in some saves. 
  Found a new search value to look for that seems to be right. 
* Intial directory for when loading saves is now the install default
  location C:\Sierra\Arcanum\Modules\Arcanum\Save.
* I changed the skills editor code so no longer does it give you the 
  warning about skills when you first load a character's skills.
* You must first open a file now in order to be able to save. Since
  if you tried to save without opening a file it crashed the program.
* Fixed the bug that made all females backgrounds say Supermodel.
* Females PCs showed up as Males. Fixed
* Jayna Stiles and Zen-Virgil are now in the editor.
* Now Dark Elf and Ogre have correct racial statistics.

Version 1.6
* Gnomes had a glitch in their willpower stat. Fixed.
* Chukka and Vollinger are now in the editor.
* Gar, Jormund, and Perriman Smythe are now in the editor.
* Magnus, Raven, and Z'an Al'urin are now in the editor.
* So far the editor is fully compatible with the full version with only
  minor bugs popping up.
* Found out that the editor did not always find Virgil and Sogg.
  Revised the search procedure and so far it worked in all tests.
* Found out the editor crashed sometimes when going to the magic
  tech portions of the editor when editng a follower after editing
  the main character. Fixed 
* Follower's backgrounds are now the same as their name.
* Female backgrounds are now in the editor.
* The editor can tell if a character is male or female now.
* Corrected a few typos.
* You can edit how many Fate points your main character has.

Version 1.5
* Found out that Constitution and Dexterity were reversed. Fixed 
* Found out the Heal skill would not raise. Fixed
* Fatigue Stat is Editable
* Basic background check is up.(Only Male backgrounds since Females are
  not part of the demo. Females will be part of first release after the
  game comes out.)
* With the basic background check up the modified stats now reflect
  background bonuses.
* Save command now tells you that it saved.
* Fatigue Stat is affected by changes in level,Constitution, and 
  Willpower as it should be.
* You can now edit Virgil and Sogg Mead Mug if you have them in your
  party and raise their level at least once during the game.(i.e. they 
  can not be at the level they are at when they join your party)
* Added an About screen so people can know what version the editor is 
  while using the editor.

Version 1.4
* Add modified stat box to better reflect the values you see when 
  playing the game. So far it reflects racial characteristics.
* Forgot to link up some of the interface for the statistics. I fixed 
  that.
* Age now reflects the true age of the character.
* Character's Alignment is fully adjustable.
* Added prelimary manual Magick/Tech bar editing. Right now it just 
  sets the bar to 100 on either side or back to 0.
* When raising your magic or tech levels the Magic/Tech bar will be 
  affected.

Version 1.3
* Found out I messed up the magic editor. Fixed it
* Made a new interface to decrease the likely hood of inputing the 
  wrong values.

Version 1.2
* Normal Skills are now editable. (Skills levels go up to level 5 and 
  do not raise the rank while your level is 0 as it screws up the other
  skills.)

Version 1.1
* Tech Editor is now started (As with magic the magic/ech bar is not 
  affected)
* Basic Age Modifier is up. ( 20 = the starting age for whatever race
  you are. Later I will try to reflect these differences.)
* You can now edit your level as well

Version 1
The current features as of right now are:
* Statistics are Editable (I limited it at a total of 20 since that is 
  the normal game max.)
* Magic Editor is started (Can give you full magic but it will not 
  affect the magic/tech bar.)
* You can give yourself more creation points (Limit of 50)



*III* POSSIBLE ADDITIONS *III*

* More editing of character stats such as resistance and derived stats.
* Health to be changable 
* Items
* Premade PCs



*IV* KNOWN PROBLEMS *IV*

* In game stats will not always reflect the values in the editor.
  These stats may not be the same due to items that you have 
  equipped.
* The editor will not work if you name the character using a single 
  letter or a word that common appears in the savefile(i.e. Arcanum,
  DEST).
* Editor does not work on pre-existing characters. It will only work on
  characters you create.
* With the addition of Follower editing you could experience problems
  when raising fatigue that is not a multiple of 4. To solve this for
  the time being just edit either your level,constitution, or willpower
  until it is a multiple of 4, then change it back after you raised 
  fatigue to where you want. 
* Whenever a a character alignment is zero it does not show up in the 
  box.
* When using the X button to close the program from Either the About,
  Skills, Tech, or Magic screens, the program stills seems to
  be running under the task window. So close the program from 
  the main screen.
* Sometimes certain Npcs have values in the magic and tech editor much
  higher then they should. What happens is that their magic tech skills
  are not editable at the time. I am not sure why the game does not save
  it all yet. So for the time being If you see a high number in this 
  section do not change it. Just close the program and start over if you
  wish to use that portion of the editor on another character still. If 
  you do not close the program before opening that section again you 
  will get an overflow error.
* Some characters might not show up(only tested in my saves which works) 
* Magick/Tech bar still says old value when switching between characters
  if the character has a value that is not yet in the choice range.



*V* INSTALLATION AND USAGE *V*

The following are instructions on installation.
Step 1 - Test the editor to see if it needs installation. (If an error
occurs you do need to install. If not you do not.)
Step 2 - Move all the ocx/dll files into your Windows/System Folder.
(In some cases you may need to overwrite files already there. It is 
best to backup these files just in case)
Step 3 - Use regsvr32 on each of the files you placed in the System 
folder. The editor should now be installed.

Usage of Editor
Step 1 - Double click on the exe file to start the editor.
Step 2 - Go to the File Menu and select the Open command.
Step 3 - Pick the save game you wish to open and edit. (Sometimes you 
will have to manually navigate to your save folder depending on how
you installed Arcanum.)
Step 4 - A name input screen should now appear. Enter your Character's
name into it.
Step 5 - Now providing the name is valid, all the stats for the
character should appear and can now be changed.
Step 6 - Make the changes that you wish.
Step 7 - Save the changes by going to file/save command. You can also
use save as to save it as another file but be warned by doing this you
will not see the changes in the game unless you rename that file to 
take the place of the tfaf file that you originally opened.
Step 8 - Exit the editor and go play enjoying the new statistics.



*VI* RACE AND GENDER EDITING *VI*

Race and gender editing is a feature that was added in Version 1.8.
It is still very experimental and can possibly screw up your game
when using. Though for most tests it has not caused any major problems.
Some points I need to address about this kind of editing is that it 
does not change the original graphic of the character in the game to
match your new race/gender. I am also not sure if your original 
race/gender bonuses/weaknesses are effected by changing it. What I can
tell you is that everyone in the game will treat you as the race/gender
you do change it to. Another point I like to add is the races of dark
elf and Ogre. Both of them you can change to but may not be such a 
good idea in the full game as most of the text for these races as pcs
are missing. The reason I did add them to the editor is for people like
myself who are building mods and want to add special quests for such 
races and wish to allow pcs who play their mod the option of becoming
these races.  



*VII* FREQUENTLY ASKED QUESTIONS *VII*

* Q - When I try to run the editor it says that *.dll (ex. Msstdfmt.dll
  or comdlg.ocx)is not correctly registered or Installed. How can I fix
  this?
  A - This problem can be solved by placing that file into your Windows
  system folder. Once you do that either: go to a Dos Prompt and type
  type "cd system" which switches you to the "\windows\system"directory
  Type "regsvr32 *.dll" (ex. msstdfmt.dll)
  Close DOS window.
  or you can go to the run command under the start menu and 
  type Regsvr32 C:\windows\system\msstdfmt.dll 

* Q - When I try to run the editor is says I am missing msvbvm60.dll. 
  I searched my computer and could not locate this file. Where can I 
  get it? 
  A - You can get the file several ways. One is to have Visual Basic 
  installed on your machine. Another is to download it off the Internet.
  A good place to start looking would be on a search engine. Type in the
  filename as the search and it should produce several sites to download
  from.

* Q - When I try to run the editor, I get the following error "System 
  Error &H8007007E (-2147024770).  The specified module could not be 
  found" What do I do to fix this? 
  A- The way to fix this error is to make sure you have the files that
  came with the editor registered on your pc. If this still does not 
  work then email me as there might have been one or two files left 
  out of the zip that you still may need.


*VIII* SPECIAL THANKS *VIII*
Special thanks to all the people who have already sent in files with
different npcs so that I could add them so soon. If anyone has an npc
in their party that is not in the editor feel free to send them in so
that npc will appear in the next version.
If anyone has a problem with the editor or wish to make a suggestion 
then I would like you to email me the problem/suggestion at 
DKoepp913@aol.com (It might help if you could supply me with your 
save game so I can further test it myself. Please if you send in your 
savegame include all 4 files: tfaf,tfai,gsi, and the bmp.
