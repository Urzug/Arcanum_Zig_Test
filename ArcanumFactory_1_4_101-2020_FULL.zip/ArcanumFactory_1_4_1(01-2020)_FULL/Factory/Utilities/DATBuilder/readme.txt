-------------------------------------
           DatBuilder 1.0
       for Arcanum modmakers
------------------------------------
(c) 2002 T. Pitk�nen a.k.a Dj Unique


I guess the name of this tool speaks for itself. Simply put, it
extracts files from Arcanum DAT files and also is able to create them.
The interface is similar to WinZip and PowerArchiver (not 100% though) and should
make DAT file management a lot easier than with dbmaker. If not, then please shoot me.

Here's a short example on how to create a DAT File from your module:
(Assuming you're using 1.0.7.0, if not, then skip this)

When you start DATBuilder, select File->New or press the "New"-button on the toolbar. You will now be prompted for a filename for the DAT file. Then you can begin adding files to the DAT. Press the small arrow down symbol on the "Add" Button of the toolbar to display the file adding methods. For most users, I would recommend using the "Add by wildcards" option. Go to the root directory of your module ( C:\Arcanum\modules\<yourmodulename> for example)
then type *.* into the editbox that has the label "Wildcard:" above it. Now click Add and the wildcard should be added to the list. Next, just click OK and wait for DATBuilder to finish adding the files. When this is finished, you'll have to finalize the DAT by pressing the Write DirTree button on the toolbar. This will write the directory structure at the end of the file. If this step is skipped, you won't be able to open the DAT because there's no information about the files inside. If you choose to add more files after finalizing, the DAT file will be rebuilt, and this process can take a long time if there is a lot of files.

Extracting files works pretty much like Winzip. You can extract either all files, or the ones you've selected. I've also included the option to extract the files with fullpathnames (which is on by default). Also if you specify a non-existent folder, it will be automatically created for you, to save any hassles with directories.


I guess that's all. Mail me at timo.pitkanen@kymp.net if encounter any problems or bugs or weird behaviour.

