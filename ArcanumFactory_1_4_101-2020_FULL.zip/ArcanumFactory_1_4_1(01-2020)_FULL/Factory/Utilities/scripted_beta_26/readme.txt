-------------------------------------------------------------------------
ScriptEd 1.0 beta 2              (c) 2001 Dj Unique       
-------------------------------------------------------------------------

This program is PURE FREEWARE! Spread it to your heart's
content!

-------------------------------------------------------------------------

THIS IS A BETA VERSION SO IT MAY NOT FUNCTION 100% CORRECTLY
BUT IN MOST CASES IT WORKS! CONSIDER YOURSELF WARNED!

READ THIS FILE FIRST BEFORE COMPLAINING ABOUT THE PROGRAM NOT WORKING!

If the compiler produces incorrect output,
please report it to me! This SHOULD NOT happen!

Also note:

Novice users with not much experience in modmaking or otherwise
technically challenged users may find this
editor a bit hard to use.
Just contact me if you need help. I'm very sorry but I can't think of a good
way to implement the interface to be more user-friendly.

After all, this is STILL a beta version, but more usable and stable now.

-------------------------------------------------------------------------

1. Introduction

ScriptEd is another alternative to SockMonkey. It provides
a different approach to script editing, in plain text format.
I personally found editing scripts with sockmonkey very painful, as
I had to constantly delete & rebuild the lines. So, I decided to write
my own script editor.
The difference between ScriptEd and SockMonkey is that ScriptEd has
to compile the scripts before they can be saved (this is because they are
shown as plain text during editing). With bigger scripts this process tends
to be very slow, but I'm going to try optimizing the compiler code to
be a little faster. (Won't be very easy I'm afraid.)
I'm not saying this would be any better than Sockmonkey but at least
it's easier to modify your scripts. 


Thanks go out to the following people for helping me with the file format:

-Sawtooth, for providing me the basic specs
-Tim Cain (da man 'imself from Troika), for telling me what the hell
 those two unknown values were


2. Which bugs have been fixed

Beta 2 fixes:

- compiler code improved, in some cases a conditional statement wouldn't
  compile at all... (Such as PC Variable 1 of Attachee) This is now fixed.
  Compiler code has been fully debugged and found working. :)
  Now it just needs to be optimized for speed.

- script parser code adjusted to allow more freedom in the syntax
  (when you compile your script, it will be neatly reformatted)
  it's now case insensitive, no matter if the text is in all uppercase and
  all lowercase =)

  NOTE: some keywords are still case sensitive though:

  Local
  Global Variable
  Global Flag
  PC Variable
  PC Flag

  This is because if I made these case insensitive, it might confuse
  the parser and produce undesired results.
  However, there's a solution for this:
  you can use the opcode macros instead of these,
  if you want. See the new features section for more details.

- in the first beta, if you typed a line like this

   0. do nothing
   10. do nothing

   it would add 9 empty lines between them
   this was fixed by removing line numbers before compiling and
   allowing them to be remapped during compile.

- a serious glitch in ArcDATlib has been fixed, which causes any other program
  trying to access the arcanum DAT files to crash on startup (namely WorldEd,
  Sockmonkey and probably Arcanum itself) when ScriptEd is running at the
  same time. Now the code has been modified to open a DAT file only when
  its files are being accessed, rather than keeping it open all the time.

3. Features (if you can call them that)

- standard windows GUI
- opcodes read directly from the .DAT file (you won't have to
  extract anything)
- no ZLIB.DLL needed, the lib is compiled into the EXE (uses version 1.1.3)
- on-the-fly conversion from .SCR to TEXT and back.
- correctly recognizes ALL data types used in the scripts 
- in this beta version, there's a syntax check option to make
  sure the output is correct, this will be useful to locate
  possible bugs in the parser code
  (if anything went wrong during the check, it'll inform about it with a message.)
- parameter replacing handled with a popup listbox
  (I'll explain this further in this README)
- access to the original game scripts via menu
- You can set the script ID from the menu and name the file without the ID
  because they are embedded together on Save.

New in Beta 2:

- Starting up is now much faster
- Moved attached variable settings and general script header
  data menu options to a script properties window (accessible from script->properties)
  All these are functional now. (finally figured out that nasty local flags thing,
  you can set them on and off, unlike in sockmonkey where you only set them on. I heard
  this is what it's supposed to do but I decided to go for this implementation)
- Added prototype ID finder
- Added a progressbar to the startup window
- Preferences dialog
- Added module selector and a module specific script loader
  this hides any reserved dir names (like "semes", "mes", "Rules" and such)
- Startup made easier. Now the preferences window will be shown
  and if you cancel the setup, it doesn't crash on you :)
- Automatic line number remapping.. for example, if you type

  0. dialog 1
  goto line 2
  1. return and SKIP default

  it will remap the lines like this:
  
  0. dialog 1
  1. goto line 2
  2. return and SKIP default

- OPCODE MACROS! YAAHOO!! script making has never been so quick, thanks to
  this amazing discovery (tm) basically these macros are search strings that
  are replaced in every script line before parsing the script to
  be processed by the compiler. They are replaced in reverse order in the list

  e.g. from the last macro to the first, to allow further macro definitions,
  like this:

  macro108=followerdlg|if npc atc has met pc plr before\n
            then dlg 1\nelse dlg 21\nrets
            \nhave critter atc become a follower of plr\n
            rets\n|
            Generates a dialog script with a line to force the
            NPC become a follower of the player.

  the first parameter in the value part is what the user should type
  to make the parser replace this string with the second parameter.
  the third parameter is the description used by the reference sheet
  (which updates itself depending on the currently defined opcode
   macros)

  Now when the macros are checked in the reverse order, all the previously
  defined keywords used in this entry are also replaced.
  The resulting script will be in this case:

  0. IF npc Attachee has met pc Player before
      THEN dialog 1
      ELSE dialog 21

  1. return and SKIP default

  2. have critter Attachee become a follower of Player

  3. return and SKIP default

  You can see all the search strings and what they replace in
  the help->Reference Sheet menu.

  New templates can be created by using the Script->Generate Script Template
  you will be prompted to specify the shortcut string and a description
  of the generated template (they are added to the end of the opcode macros list)

  And that's not all: you can also COMBINE these templates together by
  typing them in sequentially. Like this:

  followerdlg
  std_dlg

  etc...

- You can specify whether ScriptEd should automatically generate the needed
  dialogue lines by checking for lines with "dialog (num)" and "float line (num) above
  (obj)" This will certainly speed up dialogue creation, at least a little bit, perhaps? No? Okay then.
  and NO! It does not write the dialogue for you, just the placeholders
  for the initial nodes. 

- official modules can be now opened. Files will be temporarily extracted
  to their respective folders (e.g. modules\Arcanum\mes etc.) and
  deleted when you exit ScriptEd. (you must quit from file->exit for this
  to work.)

New stuff added after beta 2:

- changed the actions and conditions insertion method.
  now you select actions and conditions from script->action or condition


4. How to get started (not guaranteed to be of any help, I'm afraid)

INSTALLATION

Unzip the contents of ScriptEd_Beta2.ZIP into any directory of your choice.
Load up the editor (SCRIPTED.EXE), on the first
startup you need to specify some settings like path to Arcanum,
dialogue and .MES file editor and some others.

make sure you have the latest patch of Arcanum (1.0.7.4)
otherwise the program will not run if it finds ARCANUM4.DAT
from an older patch. (because the new opcodes ain't there)

If you choose not to load the opcode message files from the DATs 
(the checkbox saying 'read opcodes from ARCANUM3.DAT' etc etc is not checked), you
must have them in the semes-folder of your Arcanum game directory
(E.G. C:\Sierra\Arcanum\semes)

After the editor has finished loading, it is recommended to choose a module
from the File->Select module menu, for easier access to the scripts of
the mod you're probably working on. After this is done, you can either
choose an existing script from the Module: <module name>->Load Script)
or start working on a new one. (a new script is initialised on startup by default)

There's two ways to start building a script:

(NOTE: don't touch the first three lines, they are reserved)

#1:
choose either a condition or action from the menu.
Then either replace the (num)'s and (obj)'s by hand, or select the parameter you want to replace
by highlighting the (num) or (obj) text (including the colons..).
(I hope this isn't too hard.. )

#2:
if you're a true hardcore scripter, you can just type all the
commands manually. the parser is very friendly now,
and doesn't follow any strict formatting rules (not anymore :)),
but if you try to compile, and there are erroneous lines, you will be
notified about that. (so don't worry if you make a mistake, just check
that there are no spaces after the line. the parser doesn't allow this to happen,
at least for now. perhaps in later versions..)
To help even further, I have created some macros for commonly used
opcodes and variable types. They can be modified from the preferences menu
or by hand editing OPCODE_MACROS.INI with notepad.

To create a standard dialogue script, simply type
std_dlg and press ctrl-f9 to compile and expand it into a complete script.


Look at the help->reference sheet to see which macros and script
templates are available.

when you're done with your script, choose script->compile from the menu, set
the script id (script->Set Script ID) and Then save the script, without
the ID (it's appended to the filename on save, so you won't have to worry about
it). You can also save the script directly without compiling (then it will be
compiled on save, which is a bit slower, if there's a lot of complex stuff
going on [this occurred only when I was testing the compiler with the
official scripts with more than 100 lines])
        
You can also load an existing script from your module directory and edit it
or add/remove lines if necessary.

Remember: When you save your script, don't include the 5 digit script ID to
the filename, because the ID is set separately from the Script->Set Script ID
menu.

Also, you have access to all the official scripts, if you need to look for
an example. (File->Load an "official" script)


5. Future versions

If there's anything you want added to this program, then mail me
( timo.pitkanen@kymp.net ),
peep me on IRC or the Terra-Arcanum modding board.

I'm sure there's still a lot of stuff you guys want to see in the
future releases of ScriptEd. 

7. Version history:

09.12.2001       ScriptEd 1.0 Beta 1 released. No one seemed to get it
                 working properly, and it was very buggy and caused
                 all kinds of horrible things to happen. 't was the evil
                 beta 1. <gasp> But I guess we all have to start from
                 somewhere..

13.12.2001       ScriptEd 1.0 Beta 2. Major improvements made compared to the
                 previous release. Expect more updates soon.

-------------------------------------------------------------
(c) 2001 Dj Unique
[ ScriptEd uses ArcDATlib & ArcSCRlib by me ]
