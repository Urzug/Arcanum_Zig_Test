======================================================================
Arcanum Script Editor
======================================================================
http://www.labyrinth.net.au/~adsoft/arcanum
Grant Davies, October 2001.
<adsoft@labyrinth.net.au>

======================================================================
License
======================================================================
The Arcanum Script Editor is free for non-profit and non-commercial 
use.

======================================================================
Introduction
======================================================================

ScriptEditor facilitates the editing of Arcanum Script (*.scr) files.

ScriptEditor in its current form is meant as a supplement to the SockMonkey
script maker (ScrMaker) that shipped with the game.  It does vary in
functionality from SockMonkey:

- Easy to edit an already formed line (instead of erasing and
rebuilding it),

- Does not automatically remap goto line destination numbers,

- Standard MS windows interface,

- In-built option to create standard dialog script quickly

To use, unzip the contents of the archive into the same folder as
Arcanum.exe (ie, the main Arcanum folder).

Feedback is always welcome.  You can mail me at <adsoft@labyrinth.net.au>
with bugs/suggestions/comments/whatever.

======================================================================
!!IMPORTANT!!
======================================================================

Please make sure you backup all script files before using this program.
As yet, ScriptEditor has not been tested on a large scale.  As such, I
do not want to be responsible for someone losing hours of work on a 
script file!

If you are in any doubt about this, do not use this program.

======================================================================
Command Line
======================================================================

ScriptEditor accepts one optional command-line parameter - the script 
file to open.

Usage: ScriptEditor <FileName.dlg>

======================================================================
Thankyou
======================================================================
Thank you to Troika Games, for making Arcanum, and while I'm at it,
for making Fallout, a great game which reminds me of one of my favourite
games of all time, Wasteland.

======================================================================
History
======================================================================

31-Oct-2001		Initial revision
